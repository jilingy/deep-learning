package com.jilingy.deep.learning.base.test;

public interface PayStrategy {
    void pay(UserInfo userInfo);
}
